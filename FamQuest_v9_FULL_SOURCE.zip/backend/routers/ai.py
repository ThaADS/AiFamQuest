from fastapi import APIRouter, Depends, UploadFile, File, Form
from core.deps import get_current_user
from core.schemas import PlanReq
from core.ai_client import planner_plan, vision_tips_from_desc
import os, shutil, uuid
router = APIRouter()

@router.post("/planner")
async def ai_plan(req: PlanReq, payload=Depends(get_current_user)):
    return await planner_plan(req.weekContext)

@router.post("/vision_upload")
async def ai_vision_upload(file: UploadFile = File(...), description: str = Form(""), payload=Depends(get_current_user)):
    media_dir = os.getenv("MEDIA_DIR","./uploads")
    os.makedirs(media_dir, exist_ok=True)
    fname = f"{uuid.uuid4()}_{file.filename}"
    path = os.path.join(media_dir, fname)
    with open(path, "wb") as f: shutil.copyfileobj(file.file, f)
    tips = await vision_tips_from_desc(description or "dirty sink, limescale, dishes")
    public = os.getenv("PUBLIC_BASE","http://localhost:8000") + f"/uploads/{fname}"
    return {"url": public, "tips": tips}
