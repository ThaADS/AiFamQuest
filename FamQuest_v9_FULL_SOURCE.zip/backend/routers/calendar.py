from fastapi import APIRouter, Depends
from core.deps import get_current_user
router = APIRouter()
@router.get("")
def list_events(payload=Depends(get_current_user)):
    return [{"id":"e1","title":"Zwemles","start":"2025-11-17T17:00:00Z","end":"2025-11-17T18:00:00Z"}]
