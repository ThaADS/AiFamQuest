from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from uuid import uuid4
from datetime import datetime
from core.db import SessionLocal
from core import models
from core.deps import get_current_user, require_role
router = APIRouter()
def db():
    d = SessionLocal()
    try: yield d
    finally: d.close()
@router.post("/award_points", dependencies=[Depends(require_role(["parent"]))])
def award_points(userId: str, delta: int, reason: str="", d: Session = Depends(db), payload=Depends(get_current_user)):
    entry = models.PointsLedger(id=str(uuid4()), userId=userId, delta=delta, reason=reason, createdAt=datetime.utcnow())
    d.add(entry); d.commit()
    return {"ok": True}
@router.post("/award_badge", dependencies=[Depends(require_role(["parent"]))])
def award_badge(userId: str, code: str, d: Session = Depends(db), payload=Depends(get_current_user)):
    b = models.Badge(id=str(uuid4()), userId=userId, code=code, awardedAt=datetime.utcnow())
    d.add(b); d.commit()
    return {"ok": True}
