from fastapi import APIRouter, Depends, UploadFile, File
from core.deps import get_current_user
import os, uuid, shutil
router = APIRouter()
@router.post("/upload")
async def upload(file: UploadFile = File(...), payload=Depends(get_current_user)):
    media_dir = os.getenv("MEDIA_DIR","./uploads")
    os.makedirs(media_dir, exist_ok=True)
    fname = f"{uuid.uuid4()}_{file.filename}"
    path = os.path.join(media_dir, fname)
    with open(path, "wb") as f: shutil.copyfileobj(file.file, f)
    public = os.getenv("PUBLIC_BASE","http://localhost:8000") + f"/uploads/{fname}"
    return {"url": public}
