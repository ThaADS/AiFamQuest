from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from uuid import uuid4
from core.db import SessionLocal, Base, engine
from core import models
from core.schemas import LoginReq, RegisterReq, TokenRes, UserOut
from core.security import hash_password, verify_password, create_jwt, new_totp_secret, verify_totp
from authlib.integrations.starlette_client import OAuth
import os

Base.metadata.create_all(bind=engine)
router = APIRouter()
oauth = OAuth()
# Google
oauth.register('google',
    client_id=os.getenv('GOOGLE_CLIENT_ID'),
    client_secret=os.getenv('GOOGLE_CLIENT_SECRET'),
    server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
    client_kwargs={'scope':'openid email profile'}
)
# Microsoft
oauth.register('microsoft',
    client_id=os.getenv('MICROSOFT_CLIENT_ID'),
    client_secret=os.getenv('MICROSOFT_CLIENT_SECRET'),
    server_metadata_url='https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration',
    client_kwargs={'scope':'openid email profile'}
)
# Facebook (OAuth 2)
oauth.register('facebook',
    client_id=os.getenv('FACEBOOK_CLIENT_ID'),
    client_secret=os.getenv('FACEBOOK_CLIENT_SECRET'),
    access_token_url='https://graph.facebook.com/v12.0/oauth/access_token',
    authorize_url='https://www.facebook.com/v12.0/dialog/oauth',
    api_base_url='https://graph.facebook.com',
    client_kwargs={'scope':'email'}
)

def db():
    d = SessionLocal()
    try: yield d
    finally: d.close()

@router.post("/register", response_model=UserOut)
def register(req: RegisterReq, d: Session = Depends(db)):
    fam = models.Family(id=str(uuid4()), name=req.familyName)
    user = models.User(id=str(uuid4()), familyId=fam.id, email=req.email, displayName=req.displayName, role="parent", passwordHash=hash_password(req.password))
    d.add(fam); d.add(user); d.commit()
    return UserOut(id=user.id,familyId=user.familyId,email=user.email,displayName=user.displayName,role=user.role,locale='nl',theme='minimal')

@router.post("/login", response_model=TokenRes)
def login(req: LoginReq, d: Session = Depends(db)):
    user = d.query(models.User).filter_by(email=req.email).first()
    if not user or not verify_password(req.password, user.passwordHash): raise HTTPException(401, "Invalid credentials")
    if user.twoFAEnabled and (not req.otp or not verify_totp(user.twoFASecret, req.otp)): raise HTTPException(401, "2FA required/invalid")
    return TokenRes(accessToken=create_jwt(user.id, user.role))

@router.post("/2fa/setup")
def setup_2fa():
    secret = new_totp_secret()
    return {"secret": secret, "otpauth_url": f"otpauth://totp/FamQuest?secret={secret}&issuer=FamQuest"}

@router.get("/sso/google")
async def sso_google(request: Request):
    return await oauth.google.authorize_redirect(request, os.getenv("GOOGLE_REDIRECT_URI"))
@router.get("/sso/google/callback", response_model=TokenRes)
async def sso_google_cb(request: Request, d: Session = Depends(db)):
    token = await oauth.google.authorize_access_token(request)
    userinfo = token.get('userinfo') or {}
    email = userinfo.get('email')
    if not email: raise HTTPException(400,"No email from Google")
    user = d.query(models.User).filter_by(email=email).first()
    if not user:
        fam = models.Family(id=str(uuid4()), name="Family (Google)")
        user = models.User(id=str(uuid4()), familyId=fam.id, email=email, displayName=userinfo.get('name','Google User'), role="parent")
        d.add(fam); d.add(user); d.commit()
    return TokenRes(accessToken=create_jwt(user.id, user.role))

@router.get("/sso/microsoft")
async def sso_ms(request: Request):
    return await oauth.microsoft.authorize_redirect(request, os.getenv("MICROSOFT_REDIRECT_URI"))
@router.get("/sso/microsoft/callback", response_model=TokenRes)
async def sso_ms_cb(request: Request, d: Session = Depends(db)):
    token = await oauth.microsoft.authorize_access_token(request)
    userinfo = token.get('userinfo') or {}
    email = userinfo.get('email') or userinfo.get('preferred_username')
    if not email: raise HTTPException(400,"No email from Microsoft")
    user = d.query(models.User).filter_by(email=email).first()
    if not user:
        fam = models.Family(id=str(uuid4()), name="Family (MS)")
        user = models.User(id=str(uuid4()), familyId=fam.id, email=email, displayName=userinfo.get('name','MS User'), role="parent")
        d.add(fam); d.add(user); d.commit()
    return TokenRes(accessToken=create_jwt(user.id, user.role))

@router.get("/sso/facebook")
async def sso_fb(request: Request):
    return await oauth.facebook.authorize_redirect(request, os.getenv("FACEBOOK_REDIRECT_URI"))
@router.get("/sso/facebook/callback", response_model=TokenRes)
async def sso_fb_cb(request: Request, d: Session = Depends(db)):
    token = await oauth.facebook.authorize_access_token(request)
    async with oauth.facebook.get('me?fields=id,name,email', token=token) as resp:
        data = await resp.json()
    email = data.get('email') or f"{data.get('id')}@facebook.local"
    user = d.query(models.User).filter_by(email=email).first()
    if not user:
        fam = models.Family(id=str(uuid4()), name="Family (FB)")
        user = models.User(id=str(uuid4()), familyId=fam.id, email=email, displayName=data.get('name','FB User'), role="parent")
        d.add(fam); d.add(user); d.commit()
    return TokenRes(accessToken=create_jwt(user.id, user.role))
