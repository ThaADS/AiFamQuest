from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from uuid import uuid4
from datetime import datetime
from core.db import SessionLocal
from core import models
from core.deps import get_current_user
from core.schemas import TaskIn, TaskOut
from routers.util import audit
router = APIRouter()
def db():
    d = SessionLocal()
    try: yield d
    finally: d.close()
@router.get("", response_model=list[TaskOut])
def list_tasks(d: Session = Depends(db), payload=Depends(get_current_user)):
    familyId = d.query(models.User).filter_by(id=payload["sub"]).first().familyId
    tasks = d.query(models.Task).filter_by(familyId=familyId).all()
    return [TaskOut(id=t.id,title=t.title,desc=t.desc,due=t.due,assignees=t.assignees.split(",") if t.assignees else [],status=t.status,points=t.points,version=t.version) for t in tasks]
@router.post("", response_model=TaskOut)
def create_task(body: TaskIn, d: Session = Depends(db), payload=Depends(get_current_user)):
    u = d.query(models.User).filter_by(id=payload["sub"]).first()
    t = models.Task(id=str(uuid4()), familyId=u.familyId, title=body.title, desc=body.desc or "", due=body.due, assignees=",".join(body.assignees), points=body.points, status="open", updatedAt=datetime.utcnow())
    d.add(t); d.commit()
    audit(d, actorUserId=u.id, familyId=u.familyId, action="task.create", meta=t.title)
    return TaskOut(id=t.id,title=t.title,desc=t.desc,due=t.due,assignees=body.assignees,status=t.status,points=t.points,version=t.version)
@router.post("/{task_id}/complete", response_model=TaskOut)
def complete_task(task_id: str, d: Session = Depends(db), payload=Depends(get_current_user)):
    t = d.query(models.Task).filter_by(id=task_id).first()
    if not t: raise HTTPException(404,"Not found")
    t.status="done"; t.updatedAt=datetime.utcnow(); t.version += 1
    d.commit()
    audit(d, actorUserId=payload['sub'], familyId=t.familyId, action="task.complete", meta=t.title)
    return TaskOut(id=t.id,title=t.title,desc=t.desc,due=t.due,assignees=t.assignees.split(",") if t.assignees else [],status=t.status,points=t.points,version=t.version)
