from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import String, Integer, Boolean, DateTime, ForeignKey
from datetime import datetime
from core.db import Base

class Family(Base):
    __tablename__ = "families"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String, nullable=False)

class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    familyId: Mapped[str] = mapped_column(String, ForeignKey("families.id"))
    email: Mapped[str] = mapped_column(String, unique=True, index=True)
    displayName: Mapped[str] = mapped_column(String, default="")
    role: Mapped[str] = mapped_column(String, default="child")
    passwordHash: Mapped[str] = mapped_column(String, nullable=True)
    locale: Mapped[str] = mapped_column(String, default="nl")
    theme: Mapped[str] = mapped_column(String, default="minimal")
    twoFAEnabled: Mapped[bool] = mapped_column(Boolean, default=False)
    twoFASecret: Mapped[str] = mapped_column(String, nullable=True)
    createdAt: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Task(Base):
    __tablename__ = "tasks"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    familyId: Mapped[str] = mapped_column(String, index=True)
    title: Mapped[str] = mapped_column(String)
    desc: Mapped[str] = mapped_column(String, default="")
    due: Mapped[str] = mapped_column(String, nullable=True)
    assignees: Mapped[str] = mapped_column(String, default="")
    status: Mapped[str] = mapped_column(String, default="open")
    points: Mapped[int] = mapped_column(Integer, default=10)
    updatedAt: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    version: Mapped[int] = mapped_column(Integer, default=0)

class PointsLedger(Base):
    __tablename__ = "points_ledger"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    userId: Mapped[str] = mapped_column(String)
    delta: Mapped[int] = mapped_column(Integer)
    reason: Mapped[str] = mapped_column(String, default="")
    createdAt: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Badge(Base):
    __tablename__ = "badges"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    userId: Mapped[str] = mapped_column(String)
    code: Mapped[str] = mapped_column(String)
    awardedAt: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Reward(Base):
    __tablename__ = "rewards"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    familyId: Mapped[str] = mapped_column(String)
    name: Mapped[str] = mapped_column(String)
    cost: Mapped[int] = mapped_column(Integer, default=100)

class DeviceToken(Base):
    __tablename__ = "device_tokens"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    userId: Mapped[str] = mapped_column(String)
    platform: Mapped[str] = mapped_column(String) # ios|android|web
    token: Mapped[str] = mapped_column(String)
    createdAt: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class WebPushSub(Base):
    __tablename__ = "webpush_subs"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    userId: Mapped[str] = mapped_column(String)
    endpoint: Mapped[str] = mapped_column(String)
    p256dh: Mapped[str] = mapped_column(String)
    auth: Mapped[str] = mapped_column(String)

class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[str] = mapped_column(String, primary_key=True)
    actorUserId: Mapped[str] = mapped_column(String)
    familyId: Mapped[str] = mapped_column(String)
    action: Mapped[str] = mapped_column(String)
    meta: Mapped[str] = mapped_column(String, default="")
    createdAt: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
