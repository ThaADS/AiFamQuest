import os, time, jwt, pyotp
from passlib.context import CryptContext
JWT_SECRET = os.getenv("JWT_SECRET","dev_secret")
JWT_ISS = os.getenv("JWT_ISS","FamQuest")
JWT_AUD = os.getenv("JWT_AUD","famquest.app")
JWT_EXP_MIN = int(os.getenv("JWT_EXP_MIN","60"))
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
def hash_password(p: str) -> str: return pwd_context.hash(p)
def verify_password(p: str, h: str) -> bool: return pwd_context.verify(p, h)
def create_jwt(sub: str, role: str) -> str:
    now = int(time.time())
    payload = {"iss": JWT_ISS, "aud": JWT_AUD, "iat": now, "exp": now + JWT_EXP_MIN*60, "sub": sub, "role": role}
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")
def verify_totp(secret: str, code: str) -> bool: return pyotp.TOTP(secret).verify(code, valid_window=1)
def new_totp_secret() -> str: return pyotp.random_base32()
