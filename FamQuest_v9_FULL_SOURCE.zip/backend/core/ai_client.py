import os, httpx, json
from jsonschema import validate
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY","")
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
def _headers(): return {"Authorization": f"Bearer {OPENROUTER_API_KEY}"} if OPENROUTER_API_KEY else {}
PLAN_SCHEMA = {"type":"object","properties":{"weekPlan":{"type":"array"}},"required":["weekPlan"]}
async def _call(messages, model="openrouter/auto", temperature=0.4):
    if not OPENROUTER_API_KEY:
        return {"mock": True, "choices":[{"message":{"content": json.dumps({"weekPlan":[{"date":"2025-11-17","tasks":[{"title":"Vaatwasser"}]}]})}}]}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(OPENROUTER_URL, headers=_headers(), json={"model": model, "messages": messages, "temperature": temperature})
        r.raise_for_status()
        return r.json()
async def planner_plan(week_context: dict) -> dict:
    sys = {"role":"system","content":"Return pure JSON with keys weekPlan and fairness."}
    user = {"role":"user","content": f"Context: {json.dumps(week_context)}. JSON only."}
    res = await _call([sys,user])
    content = res["choices"][0]["message"]["content"]
    try:
        data = json.loads(content); validate(data, PLAN_SCHEMA); return data
    except Exception: return {"weekPlan":[{"date":"2025-11-17","tasks":[{"title":"Fallback taak"}]}]}
async def vision_tips_from_desc(desc: str) -> dict:
    sys = {"role":"system","content":"You are a cleaning coach. Output JSON with tips and warnings."}
    user = {"role":"user","content": f"Photo description: {desc}. JSON only."}
    res = await _call([sys,user])
    try: return json.loads(res["choices"][0]["message"]["content"])
    except Exception: return {"tips":["Warm water + vinegar"],"warnings":["Ventileer de ruimte"]}
