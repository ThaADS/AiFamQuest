from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict, Any
class TokenRes(BaseModel): accessToken: str
class LoginReq(BaseModel): email: EmailStr; password: str; otp: Optional[str] = None
class RegisterReq(BaseModel): familyName: str; email: EmailStr; password: str; displayName: str
class UserOut(BaseModel): id: str; familyId: str; email: EmailStr; displayName: str; role: str; locale: str; theme: str
class TaskIn(BaseModel): title: str; desc: Optional[str] = ""; due: Optional[str] = None; assignees: List[str] = []; points: int = 10; version: Optional[int] = 0
class TaskOut(BaseModel): id: str; title: str; desc: str; due: Optional[str] = None; assignees: List[str]; status: str; points: int; version: int
class RewardIn(BaseModel): name: str; cost: int
class RewardOut(BaseModel): id: str; name: str; cost: int
class DeviceTokenIn(BaseModel): platform: str; token: str
class WebPushSubIn(BaseModel): endpoint: str; p256dh: str; auth: str
class PlanReq(BaseModel): weekContext: Dict[str, Any]
