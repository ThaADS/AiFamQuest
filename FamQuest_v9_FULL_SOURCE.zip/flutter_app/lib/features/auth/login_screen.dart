import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../api/client.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController(text: 'parent@example.com');
  final _password = TextEditingController(text: 'secret123');
  final _otp = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Inloggen')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _email, decoration: const InputDecoration(labelText: 'E-mail')),
            TextField(controller: _password, obscureText: true, decoration: const InputDecoration(labelText: 'Wachtwoord')),
            TextField(controller: _otp, decoration: const InputDecoration(labelText: '2FA (optioneel)')),
            const SizedBox(height: 16),
            if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
            FilledButton(
              onPressed: _busy ? null : () async {
                setState(()=>_busy=true); _error=null;
                try {
                  await ApiClient.instance.login(_email.text, _password.text, otp: _otp.text.isEmpty?null:_otp.text);
                  if (context.mounted) context.go('/home');
                } catch (e) { setState(()=>_error=e.toString()); }
                finally { setState(()=>_busy=false); }
              },
              child: _busy ? const CircularProgressIndicator() : const Text('Log in')
            ),
          ],
        ),
      ),
    );
  }
}
