import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../offline_queue.dart';

class ApiClient {
  static final ApiClient instance = ApiClient._();
  ApiClient._();

  final _storage = const FlutterSecureStorage();
  String baseUrl = const String.fromEnvironment('API_BASE', defaultValue: 'http://localhost:8000');

  Future<bool> hasToken() async => (await _storage.read(key: 'accessToken'))?.isNotEmpty == true;
  Future<void> setToken(String token) async => _storage.write(key: 'accessToken', value: token);
  Future<String?> getToken() async => _storage.read(key: 'accessToken');

  Future<Map<String,dynamic>> login(String email, String password, {String? otp}) async {
    final res = await http.post(Uri.parse('$baseUrl/auth/login'), headers: {'Content-Type':'application/json'}, body: jsonEncode({'email': email, 'password': password, 'otp': otp}));
    if (res.statusCode == 200) { final data = jsonDecode(res.body); await setToken(data['accessToken']); return data; }
    throw Exception('Login failed: ${res.statusCode} ${res.body}');
  }

  Future<List<dynamic>> listTasks() async {
    final t = await getToken();
    final res = await http.get(Uri.parse('$baseUrl/tasks'), headers: {'Authorization':'Bearer $t'});
    if (res.statusCode == 200) return jsonDecode(res.body);
    throw Exception('List tasks failed');
  }

  Future<Map<String,dynamic>> createTask(Map<String,dynamic> body) async {
    final t = await getToken();
    try {
      final res = await http.post(Uri.parse('$baseUrl/tasks'), headers: {'Authorization':'Bearer $t','Content-Type':'application/json'}, body: jsonEncode(body));
      if (res.statusCode == 200) return jsonDecode(res.body);
      throw Exception('Create task failed');
    } catch (_) {
      await OfflineQueue.instance.enqueue({'op':'POST','path':'/tasks','body':body});
      return {'queued': true};
    }
  }

  Future<void> flushQueue() async {
    final t = await getToken();
    final list = await OfflineQueue.instance.load();
    for (final op in list) {
      final method = op['op'], path = op['path'], body = op['body'];
      final uri = Uri.parse('$baseUrl$path');
      if (method == 'POST') {
        await http.post(uri, headers: {'Authorization':'Bearer $t','Content-Type':'application/json'}, body: jsonEncode(body));
      }
    }
    await OfflineQueue.instance.clear();
  }

  Future<List<dynamic>> listRewards() async {
    final t = await getToken();
    final res = await http.get(Uri.parse('$baseUrl/rewards'), headers: {'Authorization':'Bearer $t'});
    if (res.statusCode == 200) return jsonDecode(res.body);
    throw Exception('List rewards failed');
  }

  Future<Map<String,dynamic>> uploadVision(String filename, List<int> bytes, {String description = ""}) async {
    final t = await getToken();
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/ai/vision_upload'));
    req.headers['Authorization'] = 'Bearer $t';
    req.fields['description'] = description;
    req.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    final res = await req.send();
    final body = await res.stream.bytesToString();
    if (res.statusCode == 200) return jsonDecode(body);
    throw Exception('Vision upload failed: ${res.statusCode} $body');
  }

  Future<Map<String,dynamic>> aiPlan(Map<String,dynamic> weekCtx) async {
    final t = await getToken();
    final res = await http.post(Uri.parse('$baseUrl/ai/planner'), headers: {'Authorization':'Bearer $t', 'Content-Type':'application/json'}, body: jsonEncode({'weekContext': weekCtx}));
    if (res.statusCode == 200) return jsonDecode(res.body);
    throw Exception('AI plan failed');
  }
}
