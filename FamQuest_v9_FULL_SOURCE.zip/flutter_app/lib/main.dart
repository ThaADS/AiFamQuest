import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'features/auth/login_screen.dart';
import 'features/home/home_screen.dart';
import 'api/client.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    final router = GoRouter(
      routes: [
        GoRoute(path:'/', builder:(c,s)=>const LoginScreen()),
        GoRoute(path:'/home', builder:(c,s)=>const HomeScreen()),
      ],
      redirect: (ctx, st) async {
        if (st.location == '/') return null;
        final ok = await ApiClient.instance.hasToken();
        if (!ok) return '/';
        return null;
      },
    );
    return MaterialApp.router(routerConfig: router, theme: ThemeData(useMaterial3: true));
  }
}
