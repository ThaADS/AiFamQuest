# FamQuest Flutter v9 — FULL SOURCE
- Foto→Vision tips, spraak→taak, offline queue, Shop/Admin/Kiosk.
## Run (web)
```bash
flutter pub get
flutter run -d chrome --dart-define=API_BASE=http://localhost:8000
```
## Run (android/ios)
```bash
flutter run --dart-define=API_BASE=http://10.0.2.2:8000
```
