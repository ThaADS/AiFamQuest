# FamQuest — PRD (v9 FULL SOURCE)
(Verkort) Zie backend/ en flutter_app/ voor implementatie; bevat AI planner, vision, SSO, push, WS, gamification, offline-first.
