# FamQuest — claude.md
- Werk met patches per feature; update Alembic bij DB-wijzigingen.
- Paden: backend/* en flutter_app/*.
